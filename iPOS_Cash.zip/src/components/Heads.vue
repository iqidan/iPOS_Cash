<template>
    <mt-header class="heads">
        <icon-font slot="left" icon="scan" />
    </mt-header>
</template>

<script>
import { Header } from 'mint-ui';

export default {
    name: 'Heads',
    components: {
        MtHeader: Header
    }
}
</script>

<style lang="scss" scoped>
@import '~/scss/helper.scss';

.heads {
    height: 100px;
    background-color: transparent;
}
</style>