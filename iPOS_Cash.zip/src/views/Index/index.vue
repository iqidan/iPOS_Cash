<template>
  <div class="index">
    <Heads />
    <router-view />
  </div>
</template>

<script>
import api from '@/api';
import Heads from 'components/Heads';

export default {
    name: 'Index',
    components: {
      Heads
    },
    data() {
        return {};
    },
    created() {
        // api.get_user_list({
        //     ty: '2',
        //     shop_code: 'A024'
        // });
    },
    methods: {
    }
};
</script>

<style lang="scss" scoped>
@import "~/scss/mixin.scss";
@import "~/scss/var.scss";

.index {
  display: flex;
  font-size: 28px;
  flex-direction: column;
  width: 750px;
  flex: 1;
}
</style>